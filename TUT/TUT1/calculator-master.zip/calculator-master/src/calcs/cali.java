package calcs;

public interface cali {
	//	method to add two numbers
	public double add(double a,	double b);
	
    //	method to subtract two numbers
	public double sub(double a,	double b);
    
	// 	method to multiply two numbers
	public double mul(double a,	double b);
    
	// 	method to divide two numbers
	public double div(double a,	double b);
}